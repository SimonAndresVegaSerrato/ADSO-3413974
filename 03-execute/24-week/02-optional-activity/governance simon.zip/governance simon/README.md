# Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas
## Monolith Governance & Architecture Framework (00 a 06)

Bienvenido a la documentación técnica, arquitectónica y de gobierno del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

Este proyecto implementa el estándar del **Monolith Governance Framework**, diseñado para garantizar un desarrollo modular, ordenado y escalable. Combina el registro de asistencia en tiempo real mediante **códigos QR dinámicos e infalsificables** con la **gestión integral y control de horarios para salones (ambientes) y fichas de formación**, evitando conflictos de espacio y cruces de horarios.

---

## 👥 Equipo de Desarrollo

El proyecto es liderado y desarrollado por un equipo ágil de **2 integrantes**:

| Desarrollador | Rol Principal | Áreas de Responsabilidad |
|---|---|---|
| **Juan Diego Hernández** | Co-Lead & Software Architect (Backend / Core) | Arquitectura del Monolito, Core de Sesiones, Motor de Asistencia QR Dinámico, Seguridad Criptográfica (JWT/Redis) y Autenticación RBAC. |
| **Simón Andrés Vega Serrato** | Co-Lead & Data / Fullstack Engineer (Frontend & Data) | Gestión y Control de Horarios de Salones y Fichas, Prevención de Traslapes, Modelado PostgreSQL, Interfaces Web/Móvil y Reportes. |

---

## 🧭 Estructura de Secciones (00 a 06)

```
.
├── 00-governance/            # Reglas de gobierno, agile para 2 devs, Git conventions, DoD, DoR y seguridad
├── 01-context/               # Contexto general, alcance del sistema, roles y glosario
├── 02-domain/                # Modelo de dominio DDD, subdominios, entidades y reglas de negocio (BR-01 a BR-12)
├── 03-product/               # Encuadre de problemas, visión estratégica, propuesta de valor y métricas
├── 04-requirements/          # Historias de usuario (HU-01 a HU-09), NFRs y matriz de trazabilidad
├── 05-architecture/          # Arquitectura Monolito Modular en capas, límites, Redis y registros ADR (001 a 004)
└── 06-data/                  # Modelado relacional PostgreSQL (esquemas por módulo), restricciones e índices
```

---

## 🗺️ Mapa Rápido de Documentación

| Sección | Documentos Clave | Propósito Explicado Fácil |
|---|---|---|
| [**00 — Governance**](./00-governance/README.md) | [`agile-conventions.md`](./00-governance/agile-conventions.md) · [`git-conventions.md`](./00-governance/git-conventions.md) · [`security-policy.md`](./00-governance/security-policy.md) | Cómo trabajan Juan Diego y Simón: flujos de Git, revisión mutua de PRs, seguridad y criterios de calidad. |
| [**01 — Context**](./01-context/README.md) | [`overview.md`](./01-context/overview.md) · [`scope.md`](./01-context/scope.md) · [`glossary.md`](./01-context/glossary.md) | Visión global: qué hace el sistema, cómo interactúan instructores y aprendices, y qué términos se usan. |
| [**02 — Domain**](./02-domain/README.md) | [`domain-map.md`](./02-domain/domain-map.md) · [`entities-and-rules.md`](./02-domain/entities-and-rules.md) · [`module-boundaries.md`](./02-domain/module-boundaries.md) | Lógica pura del negocio: reglas de QR efímero (30-300s) y reglas de horarios sin traslapes de salón ni ficha. |
| [**03 — Product**](./03-product/README.md) | [`problem-framing.md`](./03-product/problem-framing.md) · [`vision.md`](./03-product/vision.md) | Problemas que resuelve: adiós al papel, fin a los salones duplicados y asistencia tomada en <10 segundos. |
| [**04 — Requirements**](./04-requirements/README.md) | [`user-stories.md`](./04-requirements/user-stories.md) · [`non-functional.md`](./04-requirements/non-functional.md) · [`traceability-matrix.md`](./04-requirements/traceability-matrix.md) | Historias de usuario (HU-01 a HU-09) con criterios Gherkin y requerimientos de alto rendimiento. |
| [**05 — Architecture**](./05-architecture/README.md) | [`modular-monolith.md`](./05-architecture/modular-monolith.md) · [`layered-architecture.md`](./05-architecture/layered-architecture.md) · [`decisions/`](./05-architecture/decisions/README.md) | Monolito modular de alto rendimiento, fachada por módulo, Redis para tokens efímeros y decisiones ADR. |
| [**06 — Data**](./06-data/README.md) | [`database-conventions.md`](./06-data/database-conventions.md) · [`models.md`](./06-data/models.md) · [`migrations.md`](./06-data/migrations.md) | Esquemas en PostgreSQL (`auth`, `academic`, `schedules`, `session`, `attendance`, `audit`) y migraciones. |

---

## 🚀 Capacidades Principales del Sistema

1. **Llamada de Asistencia con Código QR Dinámico Efímero (JWT):** El instructor proyecta un QR en el aula que rota cada 30 a 300 segundos, firmado criptográficamente en servidor para evitar fotos o compartición remota entre aprendices.
2. **Control y Programación de Horarios sin Traslapes:** Motor inteligente que detecta y bloquea conflictos en tiempo real (un salón no puede tener 2 fichas a la vez, una ficha no puede tener 2 clases simultáneas y un instructor no puede multiplicarse).
3. **Gestión Integral de Salones (Ambientes) y Aforos:** Control detallado de aulas, talleres y laboratorios con capacidades máximas, sedes y geolocalización.
4. **Validación Antifraude Multifactor:** Validación simultánea de token QR activo, conexión a la red WiFi institucional y geocerca GPS del centro de formación.
5. **Cálculo de Horas Reales de Formación:** Soporte para doble marcación (ingreso y salida) para certificar las horas efectivas impartidas.
6. **Importación Rápida de Nóminas desde Sofia Plus:** Asignación masiva de aprendices a fichas mediante copiado y pegado con validación automática.
7. **Arquitectura de Monolito Modular en Memoria:** Máxima velocidad de respuesta en picos matutinos sin el costo ni la complejidad operativa de microservicios.
