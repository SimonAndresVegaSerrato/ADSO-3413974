# 03 — Product

Visión estratégica, definición de problemas y métricas de éxito del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🎯 Documentos de esta sección

| Documento | Pregunta que responde |
|---|---|
| [`problem-framing.md`](./problem-framing.md) | ¿Qué dolores y problemas operativos actuales resuelve el sistema (cruces de aulas, planillas de papel, fraude en asistencia)? |
| [`vision.md`](./vision.md) | ¿Cuál es la visión a futuro, los pilares de valor y los indicadores clave de rendimiento (KPIs)? |

---

**Siguiente sección:** [`04-requirements/README.md`](../04-requirements/README.md)
