# 03 — Problem Framing

Diagnóstico de las problemáticas actuales en la gestión de horarios y el control de asistencia en centros de formación profesional y académica.

---

## 🛑 Problemáticas Detectadas

### 1. Desorden y Conflictos en la Asignación de Horarios y Salones
- **Doble Ocupación de Aulas:** Con frecuencia dos instructores y fichas diferentes llegan al mismo salón al mismo tiempo debido a una planificación descentralizada en hojas de cálculo no sincronizadas.
- **Cruces de Horarios para Fichas e Instructores:** Aprendices con dos materias agendadas en la misma franja o instructores programados en dos sedes o ambientes al mismo tiempo.
- **Desconocimiento del Aforo:** Asignación de grupos numerosos (ej. 35 aprendices) a laboratorios pequeños con capacidad para 20 personas, comprometiendo la calidad formativa.

### 2. Ineficiencia y Fraude en el Control de Asistencia Manual
- **Pérdida de Tiempo Pedagógico:** El llamado a lista tradicional en papel consume entre 10 y 15 minutos por sesión, restando tiempo valioso de aprendizaje.
- **Suplantación y Fraude:** El uso de códigos QR estáticos o planillas físicas permite que un aprendiz marque por un compañero ausente o comparta una foto del código por WhatsApp.
- **Falta de Trazabilidad en Horas Reales:** No existe certeza de si el aprendiz permaneció durante toda la jornada o solo asistió al inicio.
- **Retraso en la Identificación de Deserción:** La consolidación manual de inasistencias toma semanas, impidiendo activar alertas tempranas de deserción académica.

---

## 💡 Oportunidad de Solución

Unificar en una sola plataforma moderna y de alta velocidad:
1. Un **motor centralizado de programación de horarios** que garantice la integridad de espacios físicos y grupos sin conflictos.
2. Un **mecanismo de asistencia por QR dinámico rotativo efímero con validación de red y geocerca**, asegurando presencia real y captura en menos de 10 segundos.

---

**Relacionado:** [`vision.md`](./vision.md) · [`../04-requirements/user-stories.md`](../04-requirements/user-stories.md)
