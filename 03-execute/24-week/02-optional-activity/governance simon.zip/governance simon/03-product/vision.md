# 03 — Product Vision

Visión estratégica, pilares de producto y métricas de éxito (KPIs) del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🌟 Declaración de Visión

> *"Brindar a instituciones educativas y centros de formación una plataforma integral, moderna y segura que erradique los conflictos de horarios y salones, y automatice el registro de asistencia mediante códigos QR dinámicos e infalsificables, maximizando el tiempo efectivo de formación y la transparencia académica."*

---

## 🏛️ Pilares de Producto

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PILARES ESTRATÉGICOS DEL PRODUCTO                     │
├──────────────────────┬──────────────────────┬───────────────────────────────┤
│ 1. Cero Conflictos   │ 2. Asistencia QR     │ 3. Horas Reales y             │
│    de Horarios       │    Infalsificable    │    Analítica Temprana         │
├──────────────────────┼──────────────────────┼───────────────────────────────┤
│ Asignación perfecta  │ Tokens dinámicos de  │ Doble marcación precisa       │
│ de salones, fichas e │ rotación corta (30s) │ (check-in/check-out) con      │
│ instructores con     │ con validación IP/GPS│ reportes instantáneos para    │
│ control de aforos.   │ para registro en 5s. │ mitigar la deserción escolar. │
└──────────────────────┴──────────────────────┴───────────────────────────────┘
```

---

## 📊 Métricas de Éxito (KPIs)

| Indicador (KPI) | Situación Actual (Manual) | Meta con el Sistema |
|---|---|---|
| **Tiempo de registro de asistencia** | 10 – 15 minutos por clase | **< 10 segundos** por aprendiz |
| **Tasa de conflictos o traslapes de aulas** | 5% – 12% semanal | **0%** (Bloqueo automático) |
| **Tasa de intentos fraudulentos exitosos** | Alta (copia de firmas / fotos de QR) | **0%** (Tokens JWT rotativos en Redis) |
| **Tiempo de consolidación de reportes** | 3 a 7 días hábiles | **Tiempo real (< 1 segundo)** |
| **Precisión en cómputo de horas reales** | Estimada / Inexacta | **100% exacta** vía doble marcación |

---

**Relacionado:** [`problem-framing.md`](./problem-framing.md) · [`../04-requirements/user-stories.md`](../04-requirements/user-stories.md)
