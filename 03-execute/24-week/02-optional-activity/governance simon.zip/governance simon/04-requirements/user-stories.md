# 04 — User Stories

Historias de usuario del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** estructuradas con criterios de aceptación en formato Gherkin (*Given / When / Then*).

---

### HU-01: Creación y Programación de Horarios de Salones y Fichas
**Como** Coordinador Académico  
**Quiero** programar franjas horarias asignando un salón, una ficha de aprendices y un instructor  
**Para** planificar el cronograma formativo semanal de manera centralizada y ordenada.

- **Criterios de Aceptación:**
  - **Given** que el coordinador ha iniciado sesión con permisos académicos,
  - **When** selecciona una Sede, Salón, Ficha, Instructor, Días de la semana y Franja horaria (hora inicio y fin),
  - **Then** el sistema verifica la disponibilidad del salón, ficha e instructor,
  - **And** si no existen cruces, guarda la asignación en estado `ACTIVA` y la refleja en la cuadrícula de horarios.

---

### HU-02: Detección Automática y Bloqueo de Traslapes de Horarios
**Como** Coordinador Académico  
**Quiero** que el sistema impida guardar una asignación si el salón, la ficha o el instructor ya están ocupados  
**Para** erradicar por completo los conflictos de espacio y cruces de agenda en el centro de formación.

- **Criterios de Aceptación:**
  - **Given** que ya existe un horario asignado para el Salón "Lab 101" de 07:00 a 11:00 los Lunes,
  - **When** el usuario intenta programar otra ficha en "Lab 101" el mismo Lunes de 09:00 a 13:00,
  - **Then** el sistema bloquea la transacción de inmediato,
  - **And** despliega una alerta explicativa: *"Conflicto de Salón: El Lab 101 ya está asignado a la Ficha 2821034 en el intervalo seleccionado"*,
  - **And** registra el intento bloqueado en `AuditLog`.

---

### HU-03: Control de Aforo Máximo del Salón Asignado
**Como** Coordinador Académico  
**Quiero** recibir una alerta bloqueante si la cantidad de aprendices de la ficha supera el aforo del salón  
**Para** garantizar las condiciones pedagógicas y de seguridad del ambiente de aprendizaje.

- **Criterios de Aceptación:**
  - **Given** un salón con capacidad máxima de 25 personas y una ficha con 32 aprendices matriculados,
  - **When** el coordinador intenta asignar dicha ficha a ese salón,
  - **Then** el sistema muestra una advertencia de sobrecupo (Aforo excedido en 7 personas) y sugiere salones alternativos disponibles con suficiente capacidad.

---

### HU-04: Apertura de Sesión y Proyección de QR Dinámico por el Instructor
**Como** Instructor  
**Quiero** iniciar la sesión de clase en pantalla y proyectar un código QR que rote automáticamente  
**Para** permitir que los aprendices presentes registren su asistencia sin riesgo de copias estáticas.

- **Criterios de Aceptación:**
  - **Given** que el instructor está dentro de su horario asignado y presiona "Iniciar Asistencia",
  - **When** define la ventana de tiempo de escaneo (ej. 15 minutos) y el intervalo de rotación (ej. 30 segundos),
  - **Then** el sistema genera en pantalla un código QR firmado con JWT y lo almacena temporalmente en Redis,
  - **And** rota automáticamente el código cada 30 segundos emitiendo un nuevo token sin recargar la página,
  - **And** muestra el contador regresivo de la ventana de registro y la lista de asistentes en vivo.

---

### HU-05: Escaneo de Asistencia con QR Dinámico por el Aprendiz
**Como** Aprendiz  
**Quiero** escanear el código QR dinámico desde mi celular conectado a la red institucional  
**Para** registrar mi asistencia a clase en pocos segundos de forma transparente.

- **Criterios de Aceptación:**
  - **Given** que el aprendiz está en el salón, conectado a la red WiFi institucional y abre la cámara de escaneo,
  - **When** escanea el código QR proyectado e ingresa con sus credenciales,
  - **Then** el sistema valida que el token esté vigente en Redis, la IP pertenezca a la sede, el GPS esté en el rango y el aprendiz pertenezca a la ficha,
  - **And** guarda el registro como `PRESENTE` con la marca temporal exacta de check-in,
  - **And** muestra confirmación verde en el móvil del aprendiz.

---

### HU-06: Rechazo Antifraude de Tokens Expirados, Remotos o Duplicados
**Como** Motor de Seguridad de Asistencia  
**Quiero** rechazar solicitudes con tokens QR vencidos, fuera de la red del centro o dobles marcaciones  
**Para** evitar la suplantación y el registro fraudulento a distancia.

- **Criterios de Aceptación:**
  - **Given** un intento de registro donde el token QR ha expirado (>30s), o la IP no es institucional, o ya se registró previamente,
  - **When** se procesa la solicitud,
  - **Then** el backend rechaza la transacción con código de error HTTP 400/403,
  - **And** muestra un mensaje neutro en pantalla ("No fue posible registrar asistencia. Vuelva a escanear"),
  - **And** registra el intento anómalo en la bitácora de seguridad `AuditLog`.

---

### HU-07: Doble Marcación y Cálculo de Horas Reales (Check-in / Check-out)
**Como** Coordinador Académico e Instructor  
**Quiero** que los aprendices registren tanto su entrada como su salida de clase mediante el QR  
**Para** certificar las horas reales y efectivas de permanencia formativa.

- **Criterios de Aceptación:**
  - **Given** una sesión que requiere control de permanencia completa,
  - **When** el aprendiz registra su entrada (check-in) al inicio y su salida (check-out) al finalizar la clase,
  - **Then** el sistema calcula la diferencia horaria exacta `check_out_time - check_in_time`,
  - **And** consolida el acumulado de horas efectivas en el historial del aprendiz.

---

### HU-08: Cierre Automático de Sesión, Inasistencias y Ajustes Manuales
**Como** Instructor  
**Quiero** que los aprendices ausentes queden marcados como inasistentes automáticamente y poder justificar casos médicos  
**Para** mantener el libro de asistencia al día con respaldo formal de auditoría.

- **Criterios de Aceptación:**
  - **Given** una sesión cuya ventana de escaneo ha concluido,
  - **When** se ejecuta el cierre de sesión,
  - **Then** el sistema asigna el estado `INASISTENTE` a todos los aprendices sin marcación,
  - **And** permite al instructor modificar manualmente el estado ingresando un motivo obligatorio que queda auditado en `AuditLog`.

---

### HU-09: Importación Rápida de Nóminas desde Sofia Plus
**Como** Instructor o Coordinador  
**Quiero** pegar listados de documentos numéricos exportados desde Sofia Plus  
**Para** matricular rápidamente la nómina de aprendices en una ficha sin digitación manual individual.

- **Criterios de Aceptación:**
  - **Given** el panel de administración de una ficha,
  - **When** el usuario pega una lista de documentos y presiona "Procesar Nómina",
  - **Then** el sistema valida que cada línea sea un documento válido, asocia los aprendices a la ficha sin duplicar los existentes y entrega un resumen de registros procesados.

---

**Relacionado:** [`non-functional.md`](./non-functional.md) · [`traceability-matrix.md`](./traceability-matrix.md)
