# Plantilla de Historia de Usuario (HU)

### HU-[Número]: [Título de la Historia]

**Como** [Rol del usuario: Instructor / Aprendiz / Coordinador / Administrador]  
**Quiero** [Acción o capacidad que se desea realizar]  
**Para** [Beneficio, objetivo o valor de negocio que se obtiene]

---

### 📋 Criterios de Aceptación (Gherkin)

#### Escenario 1: [Flujo Principal Exitoso]
- **Given** [Contexto inicial o precondición del sistema]
- **When** [Acción disparadora ejecutada por el usuario]
- **Then** [Resultado observable esperado en el sistema]
- **And** [Efecto complementario o estado persistido]

#### Escenario 2: [Flujo de Error o Validación Bloqueante]
- **Given** [Contexto de error o condición no cumplida]
- **When** [El usuario intenta realizar la acción]
- **Then** [Mensaje o bloqueo seguro del sistema]

---

### 🔗 Metadatos Técnicos
- **Módulo Responsable:** `[schedules / session / attendance / academic / auth / reports / audit]`
- **Reglas de Negocio Asociadas:** `[BR-XX, BR-YY]`
- **Estimación:** `[1 / 2 / 3 / 5 / 8]` Story Points
- **Desarrollador Asignado:** `[Juan Diego Hernández / Simón Andrés Vega Serrato]`
