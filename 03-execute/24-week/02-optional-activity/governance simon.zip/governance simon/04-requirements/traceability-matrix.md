# 04 — Traceability Matrix

Matriz de trazabilidad integral que conecta Historias de Usuario (HU), Reglas de Negocio (BR), Módulos del Monolito, Decisiones de Arquitectura (ADR) y Pruebas Automatizadas.

---

## 🗺️ Matriz de Trazabilidad Cruzada

| Historia de Usuario | Reglas de Negocio (BR) | Módulo(s) Responsable(s) | Registro ADR | Tipo de Pruebas Requeridas |
|---|---|---|---|---|
| **HU-01: Programación de Horarios** | BR-01, BR-02, BR-03 | `schedules`, `academic` | ADR-001, ADR-004 | Unitarias de franjas horarias e integración con PostgreSQL. |
| **HU-02: Detección de Traslapes** | BR-01, BR-02, BR-03 | `schedules` | ADR-004 | Unitarias exhaustivas de colisión de rangos horarios y concurrencia. |
| **HU-03: Control de Aforo de Salón** | BR-04 | `schedules`, `academic` | ADR-004 | Validación de límites de capacidad de aula vs tamaño de ficha. |
| **HU-04: Apertura y QR Dinámico** | BR-05, BR-06 | `session`, `schedules` | ADR-001, ADR-002 | Pruebas de generación JWT, rotación cada 30s y TTL en Redis. |
| **HU-05: Escaneo de Asistencia QR** | BR-05, BR-07, BR-08, BR-09 | `attendance`, `session`, `academic` | ADR-002, ADR-003 | Integración E2E de escaneo, validación de IP y Haversine GPS. |
| **HU-06: Rechazo Antifraude** | BR-05, BR-06, BR-07, BR-10 | `attendance`, `audit` | ADR-002, ADR-003 | Pruebas de seguridad con tokens caducados, IPs ajenas y reintentos. |
| **HU-07: Doble Marcación (Horas)** | BR-12 | `attendance` | ADR-001 | Cálculo matemático de delta temporal (check-in / check-out). |
| **HU-08: Cierre e Inasistencias** | BR-11 | `attendance`, `session`, `audit` | ADR-001 | Pruebas de batch para asignación de inasistencias al vencer ventana. |
| **HU-09: Importación Sofia Plus** | BR-09 | `academic` | ADR-001 | Pruebas unitarias de parseo de texto, sanitización y no duplicación. |

---

**Relacionado:** [`user-stories.md`](./user-stories.md) · [`non-functional.md`](./non-functional.md) · [`../02-domain/entities-and-rules.md`](../02-domain/entities-and-rules.md)
