# 04 — Requirements

Requerimientos funcionales y no funcionales del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📚 Documentos de esta sección

| Documento | Contenido Principal |
|---|---|
| [`user-stories.md`](./user-stories.md) | Historias de usuario formales (**HU-01 a HU-09**) con criterios de aceptación en sintaxis Gherkin (*Given / When / Then*). |
| [`non-functional.md`](./non-functional.md) | Requisitos no funcionales (rendimiento en picos, seguridad, disponibilidad 99.5%, portabilidad). |
| [`traceability-matrix.md`](./traceability-matrix.md) | Matriz de trazabilidad que conecta HUs, Reglas de Negocio (BR), Módulos y Pruebas. |
| [`_template-hu.md`](./_template-hu.md) | Plantilla estándar para la creación de nuevas historias de usuario. |

---

**Siguiente sección:** [`05-architecture/README.md`](../05-architecture/README.md)
