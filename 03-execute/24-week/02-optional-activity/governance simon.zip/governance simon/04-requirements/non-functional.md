# 04 — Non-Functional Requirements (NFR)

Requerimientos no funcionales de rendimiento, seguridad, disponibilidad, usabilidad y mantenibilidad para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## ⚡ 1. Rendimiento y Escalabilidad (Performance)

- **NFR-01 (Latencia de Escaneo QR):** El tiempo de respuesta para validar un token QR dinámico y registrar el check-in no debe superar los **500 ms** bajo condiciones normales.
- **NFR-02 (Validación en Memoria con Redis):** La verificación de expiración y firma de tokens QR dinámicos se realiza en caché Redis con latencias sub-milisegundo (< 10 ms).
- **NFR-03 (Capacidad Concurrente en Picos Matutinos):** El monolito debe soportar al menos **500 peticiones de escaneo simultáneas por segundo** al inicio de las franjas horarias (ej. 07:00 AM) sin degradación del servicio.
- **NFR-04 (Detección de Traslapes en Tiempo Real):** El cálculo de disponibilidad de salones y detección de conflictos debe resolverse en menos de **200 ms** mediante índices espaciales/temporales (`GIST` en PostgreSQL).

---

## 🔒 2. Seguridad e Integridad (Security)

- **NFR-05 (Criptografía de Tokens):** Los códigos QR dinámicos están protegidos por tokens JWT firmados con algoritmo `HMAC-SHA256` y clave secreta rotada periódicamente.
- **NFR-06 (Protección de Contraseñas):** Almacenamiento seguro de credenciales mediante `bcrypt` con costo 12 o `Argon2id`.
- **NFR-07 (Inmutabilidad de Auditoría):** Las tablas de auditoría (`audit.audit_logs`) solo admiten operaciones de inserción (`INSERT`), prohibiendo modificaciones (`UPDATE`) o eliminaciones (`DELETE`).

---

## ⏱️ 3. Disponibilidad y Confiabilidad (Availability)

- **NFR-08 (SLA del Servicio):** Disponibilidad garantizada del **99.5%** durante el horario académico institucional (06:00 AM a 10:00 PM).
- **NFR-09 (Tolerancia a Caídas de Red Móvil):** Si el aprendiz pierde cobertura celular momentáneamente, la interfaz móvil retiene el intento de validación localmente hasta reconectar con la red institucional.

---

## 📱 4. Usabilidad y Accesibilidad (Usability)

- **NFR-10 (Diseño Móvil Primero para Aprendices):** La interfaz de escaneo debe ser 100% responsiva, intuitiva y accesible desde cualquier navegador móvil moderno (Chrome, Safari, Firefox) sin obligar a instalar apps pesadas.
- **NFR-11 (Claridad en la Cuadrícula de Horarios):** El módulo web de horarios debe ofrecer visualización clara por día, semana, salón y ficha, con código de colores según el estado de ocupación.

---

**Relacionado:** [`user-stories.md`](./user-stories.md) · [`traceability-matrix.md`](./traceability-matrix.md)
