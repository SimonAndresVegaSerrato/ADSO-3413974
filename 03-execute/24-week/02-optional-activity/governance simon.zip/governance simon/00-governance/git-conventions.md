# 00 — Git Conventions

Estándares de control de versiones, ramas y mensajes de commit para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🌳 Estrategia de Ramas (Trunk & Feature Branching para 2 Devs)

```
main                             Producción estable. Despliegues oficiales.
  └── dev                        Integración continua (CI/CD).
        ├── feat/[código-hu]-[nombre]  Nuevas funcionalidades (ej. horarios, QR dinámico)
        ├── fix/[código-hu]-[nombre]   Correcciones de errores en desarrollo
        ├── chore/[nombre]             Configuración, Docker, dependencias o docs
        └── hotfix/[nombre]            Parche urgente nacido directamente de main
```

- **Protección de Ramas:** Las ramas `main` y `dev` están protegidas. No se permiten `git push --force` ni commits directos sin Pull Request.
- Cada funcionalidad se desarrolla en una rama propia y se elimina tras su integración.

---

## 🏷️ Nomenclatura de Ramas

Formato obligatorio: `[tipo]/[identificador]-[descripción-kebab-case]`

Ejemplos:
- `feat/HU-01-room-and-schedule-management` (Desarrollado por Simón Andrés)
- `feat/HU-02-schedule-conflict-detection` (Desarrollado por Simón Andrés)
- `feat/HU-03-instructor-dynamic-qr-generation` (Desarrollado por Juan Diego)
- `feat/HU-04-apprentice-qr-scan-validation` (Desarrollado por Juan Diego)
- `fix/HU-05-redis-ttl-token-expiry`
- `chore/docker-compose-postgres-redis-setup`

---

## ✍️ Formato de Commits (Conventional Commits)

Cada commit debe seguir la estructura:
`tipo(módulo): descripción imperativa en minúsculas sin punto final`

### Módulos válidos para el scope:
- `schedules`: Creación de franjas horarias, asignación de salones/fichas, detección de traslapes.
- `session`: Gestión de sesiones de clase, proyección de QR dinámico, TTL en Redis.
- `attendance`: Motor de validación antifraude (IP/GPS/JWT), check-in, check-out y horas reales.
- `academic`: Gestión de sedes, salones, fichas, aprendices e importación Sofia Plus.
- `auth`: Autenticación, JWT de sesión de usuario y roles (RBAC).
- `reports`: Reportes de asistencia, inasistencias y ocupación de salones.
- `audit`: Bitácora inmutable de eventos de seguridad y cambios manuales.

### Tipos de commit:
| Tipo | Uso | Ejemplo |
|---|---|---|
| `feat` | Nueva funcionalidad | `feat(schedules): agregar algoritmo de deteccion de traslape para salones` |
| `feat` | Nueva funcionalidad QR | `feat(session): implementar rotacion de token qr firmado cada 30 segundos` |
| `fix` | Corrección de error | `fix(attendance): corregir calculo de distancia en geocerca gps haversine` |
| `refactor`| Mejora de código | `refactor(schedules): optimizar consulta de ocupacion semanal de ambientes` |
| `test` | Pruebas | `test(attendance): anadir pruebas de rechazo para tokens qr expirados` |
| `docs` | Documentación | `docs(governance): actualizar convenciones de revision para equipo de 2` |
| `chore` | Tareas generales | `chore(database): configurar indices gist para rangos horarios` |

---

## 🔄 Política de Pull Requests y Revisión Mutua

1. **Revisión Cruzada Obligatoria (1 Aprobación Requerida):**
   - Cuando **Juan Diego Hernández** abre un PR, el revisor asignado es **Simón Andrés Vega Serrato**.
   - Cuando **Simón Andrés Vega Serrato** abre un PR, el revisor asignado es **Juan Diego Hernández**.
2. **Requisitos para Merge:**
   - Aprobación formal (Approve) del compañero de equipo.
   - Todos los tests automatizados (CI) en verde.
   - Sin conflictos con la rama base `dev`.
3. **Estrategia de Merge:**
   - **Squash and Merge:** Obligatorio para ramas `feat/` o `fix/` hacia `dev` (un solo commit limpio por funcionalidad).
   - **Merge Commit:** Reservado exclusivamente para la integración de `dev` a `main` al lanzar una versión.

---

**Relacionado:** [`agile-conventions.md`](./agile-conventions.md) · [`definition-of-done.md`](./definition-of-done.md)
