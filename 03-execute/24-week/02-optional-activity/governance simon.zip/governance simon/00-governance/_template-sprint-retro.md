# Plantilla de Retrospectiva de Sprint

**Sprint:** `Sprint #[Número]`  
**Fechas:** `[Fecha Inicio] — [Fecha Fin]`  
**Participantes:** Juan Diego Hernández, Simón Andrés Vega Serrato  

---

## 🎯 Resumen del Sprint
- **Puntos Comprometidos:** `[X]` SP
- **Puntos Completados:** `[Y]` SP
- **Historias Entregadas:**
  - `[HU-XX]`: [Descripción breve]
  - `[HU-YY]`: [Descripción breve]

---

## 🟢 ¿Qué funcionó muy bien?
- *Ejemplo: La comunicación directa facilitó resolver rápido la integración entre el módulo de horarios y las sesiones QR.*
- *Ejemplo: Las revisiones de PR fueron rápidas y detectaron a tiempo una condición de carrera en Redis.*

---

## 🟡 ¿Qué podemos mejorar?
- *Ejemplo: Definir con mayor detalle las pruebas para traslapes complejos de horarios antes de codificar.*
- *Ejemplo: Automatizar la ejecución de migraciones en el entorno local.*

---

## 🚀 Acciones de Mejora Acordadas (Action Items)

| Acción / Compromiso | Responsable | Fecha Límite |
|---|---|---|
| Implementar pruebas de carga para escaneo concurrente de QR | Juan Diego Hernández | Sprint siguiente |
| Añadir validación visual de horarios en el frontend | Simón Andrés Vega Serrato | Sprint siguiente |

---
