# 00 — Documentation Rules

Estándares y principios para mantener la documentación técnica del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** clara, estructurada y siempre sincronizada con el código fuente.

---

## 🎯 Principios Fundamentales

1. **Claridad y Simplicidad:** Redactar en un lenguaje comprensible, técnico y conciso. Evitar redundancias y conceptos abstractos sin ejemplos.
2. **Estructura Modular (00 a 06):** Ningún documento debe salirse de su propósito definido en la sección correspondiente:
   - `00-governance`: Cómo trabajamos (acuerdos de equipo, git, calidad, seguridad).
   - `01-context`: Qué es el sistema, su entorno, usuarios y alcance.
   - `02-domain`: Qué reglas e invariantes gobiernan el negocio (DDD).
   - `03-product`: Por qué existe el producto, su visión y métricas de éxito.
   - `04-requirements`: Qué debe hacer el sistema (historias de usuario en Gherkin y NFRs).
   - `05-architecture`: Cómo está construido el software por dentro (módulos, capas, Redis, ADRs).
   - `06-data`: Cómo se almacenan los datos (PostgreSQL, modelos, índices, migraciones).
3. **Diagramas Vivos en Mermaid:** Todo flujo, arquitectura o relación debe modelarse usando bloques de código ````mermaid```` para mantenerlos versionables y legibles.
4. **Trazabilidad Continua:** Cada regla de negocio (BR), historia de usuario (HU), registro de decisión (ADR) y tabla de base de datos debe tener un código identificador único y referencias cruzadas.
5. **Mantenimiento en Tiempo Real:** Cualquier refactor que cambie un flujo o regla de negocio debe incluir la actualización de la documentación en el mismo Pull Request.

---

**Responsables:** Juan Diego Hernández & Simón Andrés Vega Serrato
