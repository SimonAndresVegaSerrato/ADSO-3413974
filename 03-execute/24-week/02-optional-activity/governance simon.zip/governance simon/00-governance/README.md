# 00 — Governance

Documentación sobre cómo el equipo de desarrollo del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** toma decisiones, define estándares de calidad, gestiona el código fuente y asegura la entrega continua.

## 👥 Estructura del Equipo

El equipo de desarrollo está conformado por:
- **Juan Diego Hernández:** Co-Lead & Software Architect (Backend, Asistencia QR, Sesiones, Seguridad).
- **Simón Andrés Vega Serrato:** Co-Lead & Fullstack / Data Engineer (Frontend, Horarios, Salones, Fichas, Base de Datos).

---

## 📚 Documentos de esta sección

| Documento | Pregunta que responde | Responsables |
|---|---|---|
| [`agile-conventions.md`](./agile-conventions.md) | ¿Cómo organizamos los sprints, estimaciones y ceremonias para nuestro equipo de 2? | Juan Diego Hernández & Simón Andrés Vega Serrato |
| [`definition-of-ready.md`](./definition-of-ready.md) | ¿Cuándo una historia de usuario está lista para programarse? | Juan Diego Hernández & Simón Andrés Vega Serrato |
| [`definition-of-done.md`](./definition-of-done.md) | ¿Cuándo una funcionalidad se considera 100% terminada y lista para Staging/Producción? | Todo el equipo |
| [`git-conventions.md`](./git-conventions.md) | ¿Cómo estructuramos ramas, commits y el flujo de revisión mutua en Pull Requests? | Juan Diego Hernández & Simón Andrés Vega Serrato |
| [`security-policy.md`](./security-policy.md) | ¿Cómo protegemos los tokens QR dinámicos, llaves criptográficas y datos de fichas y aprendices? | Juan Diego Hernández |
| [`documentation-rules.md`](./documentation-rules.md) | ¿Qué reglas de claridad y formato debe cumplir la documentación técnica? | Todo el equipo |
| [`_template-sprint-retro.md`](./_template-sprint-retro.md) | ¿Qué plantilla usamos para documentar los aprendizajes y mejoras de cada sprint? | Simón Andrés Vega Serrato |

---

**Siguiente sección:** [`01-context/README.md`](../01-context/README.md)
