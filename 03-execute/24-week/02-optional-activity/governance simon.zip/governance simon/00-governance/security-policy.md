# 00 — Security Policy

Políticas de seguridad, cifrado, protección de datos y control de accesos para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🔐 1. Seguridad de Tokens QR Dinámicos (Antifraude)

Para evitar que los aprendices se envíen fotografías del código QR por mensajería instantánea o registren asistencia de forma remota:

1. **Tokens Criptográficos Efímeros (JWT):**
   - Cada código QR proyectado contiene un token JWT firmado mediante `HMAC-SHA256` utilizando una clave secreta del servidor.
   - **Vigencia Ultracorta:** El token expira automáticamente entre 30 y 300 segundos (configurable por el instructor).
   - El payload del token contiene: `session_id`, `room_id`, `ficha_id`, `nonce_rotativo`, `iat` (emitido en) y `exp` (expira en).
2. **Validación de Unicidad en Redis:**
   - Cada token activo se almacena temporalmente en Redis con un TTL equivalente a su ciclo de rotación.
   - Al generarse el siguiente código QR, el token previo queda invalidado inmediatamente.
3. **No Reutilización:**
   - Un token no puede ser utilizado más de una vez por el mismo usuario para registrar asistencia.

---

## 🛡️ 2. Validación de Presencia Física (Red y Geocerca)

1. **Restricción de Red WiFi Institucional:**
   - El backend valida que la dirección IP pública del dispositivo que escanea pertenezca a los rangos autorizados de la sede donde se ubica el salón asignado.
2. **Geocerca GPS:**
   - El dispositivo móvil del aprendiz transmite coordenadas de geolocalización. El backend calcula la distancia mediante la fórmula de Haversine y rechaza solicitudes si superan el radio de tolerancia configurado para la sede/salón (ej. 100-150 metros).

---

## 👥 3. Control de Acceso Basado en Roles (RBAC)

| Rol | Permisos de Horarios | Permisos de Asistencia QR | Permisos Administrativos |
|---|---|---|---|
| **Aprendiz** | Consultar su horario asignado de ficha y salón. | Escanear QR dinámico para registrar entrada/salida; ver su historial. | Solo lectura de sus propios datos. |
| **Instructor** | Consultar sus horarios y salones asignados. | Abrir sesión de clase, proyectar QR dinámico, registrar justificaciones manuales. | Cargar nóminas de aprendices en sus fichas. |
| **Coordinador Académico** | Crear, modificar y gestionar horarios de salones y fichas; resolver traslapes. | Monitorear asistencias en tiempo real; auditar bitácoras. | Exportar reportes consolidados y alertas de deserción. |
| **Administrador TI** | Configuración global de sedes, aforos y tipos de salones. | Parámetros de rotación de tokens QR y claves JWT. | Gestión completa de usuarios, roles e infraestructura. |

---

## 🗄️ 4. Protección de Datos y Privacidad

- **Contraseñas:** Hasheadas con `bcrypt` (factor de costo mínimo: 12) o `Argon2id`.
- **Secretos y Variables de Entorno:** Prohibido almacenar credenciales en el repositorio de código. Se inyectan en tiempo de ejecución vía `.env` o gestor de secretos.
- **Bitácora de Auditoría Inmutable:** Cada modificación manual de horario o justificación de asistencia genera un registro inmutable en `audit.audit_logs` con ID de usuario, IP, timestamp y motivo obligatorio.

---

**Responsable:** Juan Diego Hernández & Simón Andrés Vega Serrato  
**Relacionado:** [`git-conventions.md`](./git-conventions.md) · [`../05-architecture/decisions/records/ADR-002-dynamic-jwt-signed-qr-validation.md`](../05-architecture/decisions/records/ADR-002-dynamic-jwt-signed-qr-validation.md)
