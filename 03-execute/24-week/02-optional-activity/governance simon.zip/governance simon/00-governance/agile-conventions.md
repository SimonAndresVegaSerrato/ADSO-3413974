# 00 — Agile Conventions

Convenciones de trabajo ágil adaptadas para el equipo de desarrollo de 2 integrantes (**Juan Diego Hernández** y **Simón Andrés Vega Serrato**) en el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## ⏱️ Cadencia de Sprints

- **Duración del Sprint:** 2 semanas (10 días hábiles).
- **Inicio de Sprint:** Lunes 08:00 AM (Planificación y priorización conjunta).
- **Cierre de Sprint:** Viernes 04:00 PM de la segunda semana (Demostración funcional y Retrospectiva).

---

## 🤝 Ceremonias Adaptadas para 2 Desarrolladores

Para maximizar la productividad y evitar burocracia innecesaria en un equipo de 2 personas, las ceremonias se ejecutan de manera directa y colaborativa:

| Ceremonia | Frecuencia y Duración | Participantes | Dinámica y Resultado Esperado |
|---|---|---|---|
| **Sprint Planning** | Cada 2 semanas, 1 hora | Juan Diego Hernández & Simón Andrés Vega Serrato | Revisión de backlog, selección de HUs (Horarios / Asistencia QR) y asignación consensuada. |
| **Daily Sync (Standup)** | Diario, 10 minutos | Juan Diego & Simón Andrés | Sincronización rápida: ¿Qué completé ayer? ¿Qué construiré hoy? ¿Hay algún bloqueo o dependencia entre módulos? |
| **Peer Code Review** | Continuo (al abrir PR) | Juan Diego & Simón Andrés | Revisión cruzada obligatoria: Juan Diego revisa el código de Simón y Simón el de Juan Diego. |
| **Sprint Demo & Review** | Cada 2 semanas, 45 minutos | Juan Diego & Simón Andrés (con stakeholders/usuarios) | Validación de software funcional en ambiente Staging (escaneo real de QR y asignación de horarios sin conflictos). |
| **Sprint Retrospective** | Cada 2 semanas, 30 minutos | Juan Diego & Simón Andrés | Análisis de qué funcionó bien, qué mejorar y acuerdos técnicos basados en [`_template-sprint-retro.md`](./_template-sprint-retro.md). |

---

## 🔢 Estimación y Planificación

- **Unidad de medida:** Puntos de Historia (Story Points) basados en Fibonacci (1, 2, 3, 5, 8).
- **Mecanismo:** Consenso directo entre Juan Diego y Simón. Si hay discrepancia (ej. 3 vs 5), se discute la complejidad técnica del módulo (Redis, transacciones SQL, interfaces) hasta llegar a un acuerdo.
- **Límite por Historia:** Máximo 8 puntos. Cualquier historia de 13+ puntos debe dividirse en sub-historias independientes (ej. dividir "Gestión de Horarios" en "CRUD de Salones" y "Algoritmo de Detección de Traslapes").

---

## 📋 Tablero de Trabajo (Kanban Board)

El tablero de control sigue el flujo estricto:

```
[Backlog] ➔ [Ready (DoR)] ➔ [In Progress] ➔ [In Code Review (PR)] ➔ [Testing / QA] ➔ [Done (DoD)]
```

> [!IMPORTANT]
> **Regla de Oro del Tablero:** Ninguna tarjeta pasa a `Done` sin:
> 1. Aprobación formal del compañero en GitHub (Pull Request aprobado).
> 2. Pruebas automatizadas en verde (validación de horarios y verificación de tokens QR).

---

**Relacionado:** [`definition-of-ready.md`](./definition-of-ready.md) · [`definition-of-done.md`](./definition-of-done.md) · [`git-conventions.md`](./git-conventions.md)
