# 00 — Definition of Done (DoD)

Criterios de calidad que debe satisfacer cualquier funcionalidad o corrección antes de ser marcada como **Done (Terminada)** e integrada a la rama de integración `dev` o producción `main`.

---

## 🎯 Lista de Chequeo de Salida (DoD Checklist)

Una tarea sólo se mueve a la columna **Done** cuando se cumplen todos los siguientes criterios:

1. **Código Fuente y Estándares:**
   - [ ] Implementación completa de la funcionalidad y de todos los criterios de aceptación Gherkin.
   - [ ] El código cumple con las directrices de arquitectura en capas y llamadas intermodulares solo vía *Facades*.
   - [ ] Código limpio, sin variables no utilizadas ni credenciales quemadas (*hardcoded*).
2. **Pruebas Automatizadas:**
   - [ ] Pruebas unitarias para las reglas de negocio críticas (detección de traslapes en horarios, expiración de tokens QR, validación de IP y geocerca).
   - [ ] Cobertura de pruebas mínima del **80%** en la capa de dominio y aplicación.
   - [ ] Todos los tests del proyecto ejecutan y aprueban exitosamente (`pytest`).
3. **Persistencia y Base de Datos:**
   - [ ] Si hubo cambios en el modelo, se incluyeron los scripts de migración versionados en `06-data/migrations.md`.
   - [ ] Restricciones de integridad referencial e índices creados adecuadamente.
4. **Revisión de Código por Pares (Peer Review):**
   - [ ] Pull Request abierto hacia `dev` siguiendo los Conventional Commits.
   - [ ] PR revisado y **aprobado** por el compañero (Juan Diego aprueba a Simón / Simón aprueba a Juan Diego).
5. **Documentación:**
   - [ ] Documentación técnica actualizada si se introdujo una nueva regla de negocio, endpoint o entidad.
6. **Verificación en Staging:**
   - [ ] Demostrado y probado funcionalmente en el entorno de pruebas.

---

**Relacionado:** [`definition-of-ready.md`](./definition-of-ready.md) · [`git-conventions.md`](./git-conventions.md)
