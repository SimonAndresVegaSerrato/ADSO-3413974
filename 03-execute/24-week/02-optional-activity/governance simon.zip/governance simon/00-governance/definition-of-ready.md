# 00 — Definition of Ready (DoR)

Criterios formales que debe cumplir una Historia de Usuario (HU) o tarea antes de ser admitida en el Sprint Backlog por el equipo (**Juan Diego Hernández** y **Simón Andrés Vega Serrato**).

---

## ✅ Lista de Chequeo de Entrada (DoR Checklist)

Para que una historia de usuario se considere en estado **Ready** y pueda programarse en el Sprint, debe cumplir con todos los siguientes puntos:

1. **Título y Formato Estándar:**
   - Estructurada en formato formal: *Como [Rol], Quiero [Acción/Capacidad], Para [Beneficio/Valor]*.
2. **Criterios de Aceptación Claros en Formato Gherkin:**
   - Escenarios definidos con sintaxis *Given (Dado) / When (Cuando) / Then (Entonces)*.
   - Casos de éxito y casos de error contemplados (ej. escaneo exitoso vs token expirado; horario válido vs traslape detectado).
3. **Módulo y Límites Arquitectónicos Identificados:**
   - Se tiene claridad de qué módulo es responsable (`schedules`, `session`, `attendance`, `academic`, `auth`, `reports` o `audit`).
4. **Reglas de Negocio Vinculadas:**
   - Referencia explícita a las reglas de negocio aplicables (ej. BR-01 a BR-12).
5. **Impacto en Base de Datos y APIs Definido:**
   - Se conoce si requiere cambios en esquemas PostgreSQL, claves en Redis o nuevos endpoints REST.
6. **Estimación Consensuada:**
   - Estimada en Story Points por Juan Diego Hernández y Simón Andrés Vega Serrato (máximo 8 puntos).
7. **Sin Dependencias Bloqueantes Externas:**
   - No depende de tareas inconclusas de otros módulos sin resolver.

---

## 🚫 Ejemplos de Historias No Listas (Rechazadas por DoR)

* ❌ *"Hacer el módulo de horarios"* ➔ Demasiado amplia e imprecisa. Requiere dividirse en salones, asignaciones de fichas y motor de traslapes.
* ❌ *"Validar QR con Redis"* ➔ Faltan criterios de aceptación de expiración y manejo de tokens repetidos.

---

**Relacionado:** [`definition-of-done.md`](./definition-of-done.md) · [`agile-conventions.md`](./agile-conventions.md)
