# 02 — Domain Map

Clasificación de los subdominios y contextos delimitados (*Bounded Contexts*) que componen el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** según Domain-Driven Design (DDD).

---

## 🗺️ Mapa de Contextos Delimitados (Bounded Contexts)

```mermaid
flowchart TD
    subgraph CoreDomain["🎯 Core Domain (Diferenciadores y Críticos)"]
        Schedules["<b>schedules</b>\nGestión de Horarios y Salones\nMotor Anti-Traslapes y Aforos"]
        Attendance["<b>attendance</b>\nMotor Antifraude QR Dinámico\n(IP + GPS + JWT + Doble Marcación)"]
        Session["<b>session</b>\nSesión de Formación en Vivo\nRotación de QR y Caché Efímero (Redis)"]
    end

    subgraph SupportingDomain["🛠️ Supporting Domain (Soporte Operativo)"]
        Academic["<b>academic</b>\nGestión de Sedes, Salones, Fichas,\nNóminas de Aprendices y Parseo Sofia Plus"]
        Reports["<b>reports</b>\nReportes de Asistencia, Deserción\ny Ocupación de Salones (PDF/Excel)"]
    end

    subgraph GenericDomain["🧱 Generic Domain (Transversal y Reutilizable)"]
        Auth["<b>auth</b>\nAutenticación Institucional,\nRoles (RBAC) y Seguridad"]
        Audit["<b>audit</b>\nBitácora Inmutable de Seguridad\ny Cambios Manuales"]
    end

    Schedules --> Academic
    Session --> Schedules
    Session --> Academic
    Attendance --> Session
    Attendance --> Academic
    Reports --> Attendance
    Reports --> Schedules
    Attendance --> Audit
    Schedules --> Audit
    Session --> Auth
    Schedules --> Auth
    Academic --> Auth
```

---

## 🧩 Clasificación de Módulos

| Subdominio | Módulo | Tipo | Responsabilidad Principal |
|---|---|---|---|
| **Core** | `schedules` | Bounded Context | Creación y administración de franjas horarias, asignación de salones/fichas/instructores y algoritmo de prevención de traslapes. |
| **Core** | `attendance` | Bounded Context | Validación de reglas antifraude, registro de asistencia con QR dinámico, doble marcación y cálculo de horas reales. |
| **Core** | `session` | Bounded Context | Ciclo de vida de la clase en vivo, generación de QR efímero y rotación de tokens criptográficos en Redis. |
| **Supporting** | `academic` | Bounded Context | Administración de centros, sedes, salones, fichas, aprendices e importación masiva de Sofia Plus. |
| **Supporting** | `reports` | Bounded Context | Generación de consolidados de asistencia, estadísticas de ocupación de salones e indicadores de inasistencia. |
| **Generic** | `auth` | Transversal | Gestión de usuarios, credenciales, sesiones y roles (Aprendiz, Instructor, Coordinador, Admin). |
| **Generic** | `audit` | Transversal | Registro inmutable de eventos de seguridad (intentos de escaneo fallidos, traslapes bloqueados, ajustes manuales). |

---

**Relacionado:** [`entities-and-rules.md`](./entities-and-rules.md) · [`module-boundaries.md`](./module-boundaries.md)
