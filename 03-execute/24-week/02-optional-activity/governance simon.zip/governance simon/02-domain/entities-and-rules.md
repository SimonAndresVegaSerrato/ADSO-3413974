# 02 — Entities and Business Rules

Definición de las entidades fundamentales del dominio y las 12 Reglas de Negocio (**BR - Business Rules**) formales que gobiernan el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🏛️ Entidades Principales del Dominio

| Entidad | Módulo Propietario | Descripción |
|---|---|---|
| `Room` (Salón / Ambiente) | `academic` / `schedules` | Espacio físico identificado por código, nombre, tipo (aula, laboratorio, taller), aforo máximo y sede. |
| `Ficha` (Ficha de Formación) | `academic` | Cohorte o grupo caracterizado por un código numérico único, programa formativo y fecha inicio/fin. |
| `Apprentice` (Aprendiz) | `academic` | Estudiante con tipo y número de documento único, nombres, correo institucional y pertenencia a ficha. |
| `TimeSlot` (Franja Horaria) | `schedules` | Bloque temporal definido por día de la semana, hora de inicio y hora de fin. |
| `ScheduleAssignment` (Asignación) | `schedules` | Asignación que une una Ficha, un Instructor, un Salón y una Franja Horaria en un rango de fechas. |
| `TrainingSession` (Sesión en Vivo) | `session` | Instancia activa de una clase para una ficha y salón en una fecha y hora específica. |
| `QrToken` (Token Dinámico) | `session` | Token efímero firmado digitalmente (JWT) con timestamp de expiración corta (30 a 300 segundos). |
| `AttendanceRecord` (Registro Asistencia) | `attendance` | Registro individual de presencia (PRESENTE, TARDE, INASISTENTE, JUSTIFICADA), marcas de tiempo y horas reales. |
| `AuditLog` (Bitácora de Auditoría) | `audit` | Entrada inmutable que registra eventos de seguridad, bloqueos de traslapes o ajustes manuales. |

---

## 📜 Reglas de Negocio (Business Rules)

### Reglas de Control de Horarios y Salones

#### BR-01: Prevención de Traslape de Salón (No Doble Ocupación)
Un salón no puede ser asignado a más de una ficha o actividad en el mismo día y franja horaria. El motor de horarios debe rechazar automáticamente cualquier intento de asignación concurrente sobre el mismo espacio físico.

#### BR-02: Prevención de Traslape de Ficha (No Doble Clase)
Una misma ficha de formación no puede tener asignadas dos sesiones, asignaturas o salones diferentes en un mismo intervalo de tiempo.

#### BR-03: Prevención de Traslape de Instructor
Un instructor no puede estar programado simultáneamente en dos salones o con dos fichas distintas en la misma franja horaria.

#### BR-04: Control Estricto de Aforo del Salón
El número de aprendices activos matriculados en la ficha asignada no debe exceder la capacidad máxima de aforo (`max_capacity`) configurada para el salón. Si se excede, el sistema genera una advertencia bloqueante para el coordinador.

---

### Reglas de Llamada de Asistencia con QR Dinámico

#### BR-05: Expiración Estricta del Token QR Dinámico
Todo código QR proyectado tiene una vigencia máxima configurable de 30 a 300 segundos. Si el aprendiz envía el escaneo después de su expiración (`exp < now()`), el sistema rechaza la solicitud e indica refrescar el código.

#### BR-06: Firma Criptográfica Obligatoria (JWT)
El código QR contiene un token JWT firmado criptográficamente por el servidor (`HMAC-SHA256`). Se rechaza cualquier payload con firma inválida o adulterada.

#### BR-07: Validación de Red WiFi Institucional
El registro de asistencia solo se admite si la dirección IP pública del cliente solicitante pertenece al rango de red/subredes autorizadas para la sede donde se ubica el salón de la sesión.

#### BR-08: Geocerca de Validación GPS
La distancia calculada mediante la fórmula de Haversine entre las coordenadas GPS enviadas por el smartphone del aprendiz y la ubicación del centro de formación no debe exceder el radio de tolerancia parametrizado (ej. 150 metros).

#### BR-09: Pertenencia a la Ficha y Horario Activo
Solo los aprendices formalmente matriculados en la ficha asignada a la sesión y dentro del horario programado pueden registrar asistencia válida.

#### BR-10: Bloqueo de Registros Duplicados
Un aprendiz no puede registrar más de una entrada válida para la misma sesión de formación. Los intentos posteriores son rechazados y registrados en auditoría.

#### BR-11: Cierre Automático y Asignación de Inasistencia
Al expirar la ventana de escaneo de la sesión, el sistema identifica a los aprendices de la ficha sin registro de presencia y les asigna automáticamente el estado `INASISTENTE`.

#### BR-12: Doble Marcación y Cómputo de Horas Reales
Si la sesión requiere control de permanencia, las horas reales de formación se calculan como `check_out_time - check_in_time`. La falta de marcación de salida computa solo el valor mínimo configurado.

---

**Relacionado:** [`domain-map.md`](./domain-map.md) · [`module-boundaries.md`](./module-boundaries.md) · [`../04-requirements/user-stories.md`](../04-requirements/user-stories.md)
