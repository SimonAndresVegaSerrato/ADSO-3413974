# 02 — Domain

Diseño del modelo de dominio basado en **Domain-Driven Design (DDD)** para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🎯 Contenido de esta sección

Esta sección documenta las entidades, invariantes lógicas y límites de contexto que componen el núcleo del sistema, separando claramente las reglas del negocio de los detalles técnicos de infraestructura:

| Documento | Pregunta que responde |
|---|---|
| [`domain-map.md`](./domain-map.md) | ¿Cuáles son los subdominios (Core, Supporting, Generic) y cómo interactúan los módulos? |
| [`entities-and-rules.md`](./entities-and-rules.md) | ¿Qué entidades existen y cuáles son las 12 Reglas de Negocio (BR-01 a BR-12) que gobiernan horarios y asistencia? |
| [`module-boundaries.md`](./module-boundaries.md) | ¿Cómo se garantiza el aislamiento entre módulos mediante contratos y *Facades*? |

---

**Siguiente sección:** [`03-product/README.md`](../03-product/README.md)
