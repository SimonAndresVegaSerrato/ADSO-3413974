# 02 — Module Boundaries

Definición de los contratos de comunicación y límites estrictos entre módulos (*Bounded Contexts*) para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🛡️ Principio de Aislamiento de Módulos

Para preservar la modularidad del monolito y evitar acoplamientos espagueti:
1. **Acceso Exclusivo a Datos:** Ningún módulo puede consultar o escribir directamente en las tablas o esquemas de otro módulo.
2. **Comunicación Mediante Fachadas (Facades):** Todo intercambio de información entre módulos se realiza invocando métodos públicos tipados de la interfaz *Facade* del módulo correspondiente.
3. **Paso de Datos por DTOs:** No se exponen entidades de dominio internas; la comunicación se realiza mediante objetos planos inmutables de transferencia de datos (*Data Transfer Objects*).

---

## 🔌 Fachadas Principales (Facades)

```mermaid
classDiagram
    class ScheduleFacade {
        +validateRoomAvailability(roomId, timeSlot, date) bool
        +validateFichaAvailability(fichaId, timeSlot, date) bool
        +getScheduleForSession(fichaId, date, time) ScheduleDTO
        +getRoomCapacity(roomId) int
    }

    class SessionFacade {
        +openTrainingSession(scheduleId, instructorId, windowMinutes) SessionDTO
        +generateDynamicQrToken(sessionId) QrTokenDTO
        +validateTokenInRedis(sessionId, rawToken) bool
        +closeTrainingSession(sessionId) void
    }

    class AttendanceFacade {
        +registerCheckIn(token, apprenticeId, clientIp, coordinates) AttendanceDTO
        +registerCheckOut(token, apprenticeId) AttendanceDTO
        +applyManualJustification(attendanceId, instructorId, reason) void
        +processSessionAbsences(sessionId) int
    }

    class AcademicFacade {
        +getFichaApprentices(fichaId) List~ApprenticeDTO~
        +importSofiaPlusApprentices(fichaId, docList) ImportResultDTO
        +getCampusSubnetAndCoordinates(campusId) CampusDTO
    }

    SessionFacade --> ScheduleFacade : Consulta asignación y salón
    AttendanceFacade --> SessionFacade : Valida token QR activo
    AttendanceFacade --> AcademicFacade : Valida aprendiz y sede
    SessionFacade --> AcademicFacade : Carga nómina de ficha
```

---

## 🚫 Prácticas Prohibidas

- ❌ Realizar sentencias `JOIN` SQL directas entre tablas de esquemas diferentes (ej. `schedules.schedule_assignments` con `attendance.attendance_records`).
- ❌ Importar repositorios o modelos de un módulo ajeno.
- ❌ Modificar estados de asistencia desde el módulo de horarios o viceversa sin pasar por la fachada autorizada.

---

**Relacionado:** [`domain-map.md`](./domain-map.md) · [`../05-architecture/boundary-enforcement.md`](../05-architecture/boundary-enforcement.md)
