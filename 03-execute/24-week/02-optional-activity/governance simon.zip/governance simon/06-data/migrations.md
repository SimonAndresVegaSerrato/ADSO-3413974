# 06 — Migrations

Estrategia de evolución de base de datos y registro de scripts de migración versionados para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🛠️ Herramienta de Migración

- **Framework:** Alembic / Flyway / Prisma Migrate.
- **Principio:** Toda modificación a esquemas relacionales se realiza mediante archivos de migración versionados secuencialmente e integrados en el repositorio de código.
- **Rollback:** Cada migración debe implementar su método de reversión (`down`).

---

## 📜 Historial de Migraciones

| Versión | Nombre del Script | Descripción |
|---|---|---|
| `V001` | `001_initial_auth_and_audit.sql` | Creación de esquemas `auth` y `audit` con tablas de usuarios, roles y bitácoras inmutables. |
| `V002` | `002_academic_campuses_rooms_fichas.sql` | Creación del esquema `academic` con sedes, salones (aforos), fichas y nóminas de aprendices. |
| `V003` | `003_schedules_and_conflict_engine.sql` | Creación del esquema `schedules`, extensión `btree_gist`, asignaciones de horarios y restricciones anti-traslapes. |
| `V004` | `004_session_and_attendance_qr.sql` | Creación de esquemas `session` y `attendance` para sesiones en vivo, rotación QR y marcas de check-in/out. |

---

**Relacionado:** [`models.md`](./models.md) · [`database-conventions.md`](./database-conventions.md)
