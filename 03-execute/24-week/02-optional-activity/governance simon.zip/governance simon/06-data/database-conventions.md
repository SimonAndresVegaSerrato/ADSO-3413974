# 06 — Database Conventions

Convenciones de nombrado, tipos de datos y estándares de diseño para PostgreSQL en el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🗄️ Esquemas por Módulo (PostgreSQL Schemas)

Para respetar el aislamiento de dominios, las tablas se agrupan en esquemas lógicos dedicados:

- `auth`: Identidades, credenciales y roles.
- `academic`: Sedes, salones, fichas y aprendices.
- `schedules`: Franjas horarias, asignaciones de salones/fichas y restricciones anti-traslapes.
- `session`: Sesiones activas de clase y metadatos de proyección QR.
- `attendance`: Registros de presencia, check-in, check-out y horas calculadas.
- `audit`: Bitácoras inmutables de seguridad y cambios manuales.

---

## 📐 Reglas de Nombrado y Tipado

1. **Nomenclatura en Minúsculas y Plural (`snake_case`):**
   - Esquemas y tablas en minúsculas en plural: `schedules.schedule_assignments`, `attendance.attendance_records`.
   - Columnas en minúsculas en singular: `room_id`, `check_in_time`, `max_capacity`.
2. **Identificadores Únicos:**
   - Llaves primarias tipo `UUID` v4 (`gen_random_uuid()`) como estándar general. Códigos institucionales únicos (ej. número de ficha o documento) tienen restricción `UNIQUE`.
3. **Manejo de Fechas y Horas:**
   - Todos los timestamps deben usar `TIMESTAMP WITH TIME ZONE` (`TIMESTAMPTZ`) almacenados en **UTC**.
4. **Columnas de Auditoría Obligatorias:**
   - Todas las tablas de negocio incluyen: `created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()` y `updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()`.
5. **Rangos Temporales y Exclusiones:**
   - Utilizar tipos de rango `tsrange` o `tstzrange` con restricciones `EXCLUDE USING gist` para evitar traslapes de salones y fichas.

---

**Relacionado:** [`models.md`](./models.md) · [`migrations.md`](./migrations.md)
