# 06 — Data Models (PostgreSQL DDL)

Definición de tablas, campos, llaves primarias, foráneas, restricciones de exclusión e índices para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🗺️ Diagrama Entidad - Relación (ERD)

```mermaid
erDiagram
    CAMPUS ||--o{ ROOM : contains
    CAMPUS ||--o{ FICHA : hosts
    ROOM ||--o{ SCHEDULE_ASSIGNMENT : allocated_in
    FICHA ||--o{ SCHEDULE_ASSIGNMENT : attends
    FICHA ||--o{ FICHA_APPRENTICE : enrolls
    APPRENTICE ||--o{ FICHA_APPRENTICE : belongs_to
    SCHEDULE_ASSIGNMENT ||--o{ TRAINING_SESSION : instantiates
    TRAINING_SESSION ||--o{ ATTENDANCE_RECORD : records
    APPRENTICE ||--o{ ATTENDANCE_RECORD : registers

    ROOM {
        uuid id PK
        string code
        string name
        string room_type
        int max_capacity
        uuid campus_id FK
    }

    SCHEDULE_ASSIGNMENT {
        uuid id PK
        uuid room_id FK
        uuid ficha_id FK
        uuid instructor_id FK
        int day_of_week
        time start_time
        time end_time
        date valid_from
        date valid_until
        string status
    }

    TRAINING_SESSION {
        uuid id PK
        uuid schedule_assignment_id FK
        uuid instructor_id FK
        timestamptz start_time
        timestamptz end_time
        string status
        int rotation_interval_seconds
    }

    ATTENDANCE_RECORD {
        uuid id PK
        uuid session_id FK
        uuid apprentice_id FK
        string status
        timestamptz check_in_time
        timestamptz check_out_time
        numeric real_hours
        string ip_address
    }
```

---

## 📜 Definiciones SQL por Esquema

### 1. Esquema `academic` (Sedes, Salones, Fichas y Aprendices)

```sql
CREATE SCHEMA IF NOT EXISTS academic;

CREATE TABLE academic.campuses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    authorized_subnet CIDR NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    geo_radius_meters INT NOT NULL DEFAULT 150,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE academic.rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campus_id UUID NOT NULL REFERENCES academic.campuses(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    room_type VARCHAR(50) NOT NULL, -- 'AULA_TEORICA', 'LABORATORIO', 'TALLER'
    max_capacity INT NOT NULL CHECK (max_capacity > 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_room_campus_code UNIQUE (campus_id, code)
);

CREATE TABLE academic.fichas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campus_id UUID NOT NULL REFERENCES academic.campuses(id),
    code VARCHAR(50) UNIQUE NOT NULL,
    program_name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'EN_EJECUCION',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE academic.apprentices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_type VARCHAR(20) NOT NULL,
    document_number VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE academic.ficha_apprentices (
    ficha_id UUID NOT NULL REFERENCES academic.fichas(id) ON DELETE CASCADE,
    apprentice_id UUID NOT NULL REFERENCES academic.apprentices(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (ficha_id, apprentice_id)
);
```

---

### 2. Esquema `schedules` (Horarios y Asignaciones Anti-Traslapes)

```sql
CREATE SCHEMA IF NOT EXISTS schedules;
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE schedules.schedule_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES academic.rooms(id),
    ficha_id UUID NOT NULL REFERENCES academic.fichas(id),
    instructor_id UUID NOT NULL, -- Referencia a auth.users(id)
    day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7), -- 1=Lunes, 7=Domingo
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVA',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_time_order CHECK (start_time < end_time),
    CONSTRAINT chk_date_order CHECK (valid_from <= valid_until)
);

-- Índices de consulta rápida
CREATE INDEX idx_schedules_room_day ON schedules.schedule_assignments (room_id, day_of_week);
CREATE INDEX idx_schedules_ficha_day ON schedules.schedule_assignments (ficha_id, day_of_week);
```

---

### 3. Esquemas `session` y `attendance` (Sesiones en Vivo y Asistencia QR)

```sql
CREATE SCHEMA IF NOT EXISTS session;
CREATE SCHEMA IF NOT EXISTS attendance;

CREATE TABLE session.training_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_assignment_id UUID NOT NULL REFERENCES schedules.schedule_assignments(id),
    instructor_id UUID NOT NULL,
    start_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_time TIMESTAMPTZ,
    status VARCHAR(50) NOT NULL DEFAULT 'ABIERTA', -- 'ABIERTA', 'CERRADA'
    rotation_interval_seconds INT NOT NULL DEFAULT 30,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE attendance.attendance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES session.training_sessions(id) ON DELETE CASCADE,
    apprentice_id UUID NOT NULL REFERENCES academic.apprentices(id),
    status VARCHAR(50) NOT NULL, -- 'PRESENTE', 'TARDE', 'INASISTENTE', 'JUSTIFICADA'
    check_in_time TIMESTAMPTZ,
    check_out_time TIMESTAMPTZ,
    real_hours NUMERIC(5, 2) DEFAULT 0.00,
    client_ip INET,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_session_apprentice UNIQUE (session_id, apprentice_id)
);
```

---

### 4. Esquema `audit` (Bitácora Inmutable)

```sql
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE audit.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID,
    event_type VARCHAR(100) NOT NULL, -- 'MANUAL_ATTENDANCE_OVERRIDE', 'SCHEDULE_CONFLICT_BLOCKED'
    entity_name VARCHAR(100) NOT NULL,
    entity_id UUID,
    details JSONB NOT NULL,
    ip_address INET,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

**Relacionado:** [`database-conventions.md`](./database-conventions.md) · [`migrations.md`](./migrations.md)
