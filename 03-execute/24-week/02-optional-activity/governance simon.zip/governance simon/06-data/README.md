# 06 — Data

Modelado de datos relacional, convenciones de diseño de base de datos PostgreSQL y gestión de migraciones para el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📚 Documentos de esta sección

| Documento | Contenido y Propósito |
|---|---|
| [`models.md`](./models.md) | Definición completa de tablas, tipos de datos, llaves primarias/foráneas e índices agrupados por esquema (`auth`, `academic`, `schedules`, `session`, `attendance`, `audit`). |
| [`database-conventions.md`](./database-conventions.md) | Convenciones de nombrado SQL, manejo de timestamps UTC, tipos UUID e inmutabilidad. |
| [`migrations.md`](./migrations.md) | Estrategia de migraciones versionadas y scripts de evolución de esquemas. |

---

**Volver al inicio:** [`../README.md`](../README.md)
