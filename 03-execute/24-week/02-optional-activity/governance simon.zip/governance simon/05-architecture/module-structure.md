# 05 — Module Structure

Estructura de directorios y organización de clases estandarizada para cada uno de los módulos dentro del código fuente del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📁 Árbol de Carpetas por Módulo

Cada módulo (ej. `src/schedules/`, `src/attendance/`, `src/session/`) respeta el siguiente patrón de diseño:

```
src/schedules/
├── domain/                      # Capa 1: Núcleo puro del dominio
│   ├── entities/                # Entidades (Room, TimeSlot, ScheduleAssignment)
│   ├── value_objects/           # Objetos de valor (TimeRange, WeekDay, Aforo)
│   ├── exceptions/              # Excepciones de negocio (RoomOverbookedException, ScheduleConflictException)
│   └── repositories/            # Interfaces de persistencia (IScheduleRepository)
├── application/                 # Capa 2: Casos de uso y fachadas públicas
│   ├── use_cases/               # Casos de uso (AssignSchedule, DetectConflict)
│   ├── dtos/                    # Objetos de transferencia inmutables (ScheduleDTO)
│   └── facade/                  # Fachada pública (ScheduleFacade)
├── infrastructure/              # Capa 3: Adaptadores de base de datos y cache
│   ├── persistence/             # Mapeo relacional SQLAlchemy/PostgreSQL
│   └── repositories/            # Implementación concreta de IScheduleRepository
└── presentation/                # Capa 4: Endpoints REST y controladores
    ├── controllers/             # Controladores HTTP (ScheduleController)
    └── requests/                # Esquemas Pydantic / DTOs de validación de entrada
```

---

## 🔒 Regla de Exportación Pública

El archivo `src/[modulo]/__init__.py` **únicamente** exporta la interfaz de la Fachada (`Facade`), los DTOs de entrada/salida y las excepciones públicas. Todo el contenido interno de las capas `domain/`, `infrastructure/` y `presentation/` se mantiene privado para el resto de la aplicación.

---

**Relacionado:** [`layered-architecture.md`](./layered-architecture.md) · [`boundary-enforcement.md`](./boundary-enforcement.md)
