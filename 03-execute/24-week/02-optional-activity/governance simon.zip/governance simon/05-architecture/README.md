# 05 — Architecture

Documentación de arquitectura técnica, patrones estructurales y registros de decisiones arquitectónicas (**ADR**) del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📚 Documentos de esta sección

| Documento | Contenido y Propósito |
|---|---|
| [`modular-monolith.md`](./modular-monolith.md) | Visión global del estilo arquitectónico de **Monolito Modular**, interacción con Redis y PostgreSQL. |
| [`layered-architecture.md`](./layered-architecture.md) | Arquitectura en capas limpia por módulo (Domain, Application, Infrastructure, Presentation). |
| [`module-structure.md`](./module-structure.md) | Estructura interna estandarizada de carpetas y clases para cada módulo del sistema. |
| [`boundary-enforcement.md`](./boundary-enforcement.md) | Mecanismos de compilación, linters y pruebas de arquitectura para evitar fugas de acoplamiento. |
| [`decisions/`](./decisions/README.md) | Registro histórico de decisiones arquitectónicas (**ADRs 001 a 004**). |

---

**Siguiente sección:** [`06-data/README.md`](../06-data/README.md)
