# 05 — Layered Architecture

Organización interna en capas limpias (*Clean / Hexagonal Architecture*) que implementa cada módulo dentro del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🧅 Estructura de Capas por Módulo

Cada módulo (ej. `schedules`, `attendance`, `session`) se divide internamente en 4 capas concéntricas con regla de dependencia estricta hacia el centro (Dominio):

```mermaid
graph TD
    Presentation["1. Capa de Presentación (Presentation / Web)\nControllers REST, DTOs de Entrada/Salida, WebSocket Handlers"]
    Application["2. Capa de Aplicación (Application)\nUse Cases, Services, Facades, Orquestación de Flujos"]
    Domain["3. Capa de Dominio (Domain Core)\nEntidades, Value Objects, Reglas de Negocio (BR-01..12)"]
    Infrastructure["4. Capa de Infraestructura (Infrastructure)\nRepositorios PostgreSQL (SQLAlchemy/Prisma), Clientes Redis, Hash JWT"]

    Presentation --> Application
    Application --> Domain
    Infrastructure --> Domain
    Infrastructure --> Application
```

---

## 📋 Responsabilidades de Cada Capa

### 1. Capa de Dominio (`domain/`)
- Contiene la lógica pura e invariantes del negocio sin dependencias de frameworks ni librerías externas.
- **Ejemplos:** Cálculo de colisión entre dos franjas horarias (`TimeRange.overlaps()`), validación de expiración de token QR (`QrToken.isExpired()`), cálculo de horas entre check-in y check-out.

### 2. Capa de Aplicación (`application/`)
- Orquesta los casos de uso del sistema e implementa la interfaz *Facade* expuesta a otros módulos.
- **Ejemplos:** `AssignScheduleUseCase`, `GenerateDynamicQrUseCase`, `ProcessAttendanceCheckInUseCase`.

### 3. Capa de Infraestructura (`infrastructure/`)
- Implementa los adaptadores técnicos para interactuar con sistemas externos y bases de datos.
- **Ejemplos:** Adaptador de repositorio PostgreSQL para `ScheduleRepository`, cliente Redis para rotación de claves QR con TTL, cliente criptográfico JWT.

### 4. Capa de Presentación (`presentation/`)
- Expone los puntos de entrada HTTP/REST y WebSockets para navegadores y dispositivos móviles.
- **Ejemplos:** Endpoints `/api/v1/schedules`, `/api/v1/sessions/qr/stream`, `/api/v1/attendance/scan`.

---

**Relacionado:** [`module-structure.md`](./module-structure.md) · [`boundary-enforcement.md`](./boundary-enforcement.md)
