# ADR-003: Validación Antifraude por Subred Institucional y Geocerca GPS

**Estado:** Aprobado  
**Fecha:** 2026-09-19  
**Autores:** Juan Diego Hernández, Simón Andrés Vega Serrato  
**Decisores:** Equipo de Desarrollo  

---

## 1. Contexto y Planteamiento del Problema
Incluso con tokens QR rotativos, existe el riesgo residual de que un aprendiz transmita el código por videollamada en tiempo real a una persona fuera del centro de formación. Se requiere una capa adicional de validación de presencia física.

---

## 2. Opciones Consideradas

1. **Solo Validación de Token QR:**
   - *Pros:* Flujo sencillo.
   - *Contras:* Vulnerable a retransmisiones en vivo por streaming/videollamada.
2. **Validación Biométrica por Reconocimiento Facial:**
   - *Pros:* Alta certeza de identidad.
   - *Contras:* Requiere hardware costoso, procesamiento pesado y complejidades regulatorias de datos biométricos.
3. **Validación Cruzada de Subred WiFi Institucional + Geocerca GPS (Seleccionada):**
   - *Pros:* El cliente móvil debe estar conectado a la red de la sede y dentro del radio GPS del centro. Cero costo en hardware adicional.

---

## 3. Decisión Adoptada
Exigir que toda solicitud de check-in mediante QR cumpla simultáneamente con:
1. Pertenecer a la subred IP pública autorizada de la sede del salón.
2. Reportar coordenadas GPS dentro del radio de tolerancia (fórmula Haversine <= 150m).

---

## 4. Consecuencias
- **Positivas:**
  - Garantía de presencia física sin hardware adicional.
  - Blindaje completo contra escaneos remotos.
- **Desafíos:**
  - Ambientes de formación subterráneos con baja recepción GPS pueden requerir fallback a solo validación de IP WiFi institucional.

---

**Relacionado:** [`ADR-002-dynamic-jwt-signed-qr-validation.md`](./ADR-002-dynamic-jwt-signed-qr-validation.md) · [`../../../02-domain/entities-and-rules.md`](../../../02-domain/entities-and-rules.md)
