# ADR-001: Monolito Modular como Estilo Arquitectónico Base

**Estado:** Aprobado  
**Fecha:** 2026-09-19  
**Autores:** Juan Diego Hernández, Simón Andrés Vega Serrato  
**Decisores:** Equipo de Desarrollo  

---

## 1. Contexto y Planteamiento del Problema
El **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** necesita gestionar con alto rendimiento picos de escaneo simultáneo al inicio de clases, transacciones complejas para evitar traslapes de horarios y salones, y mantener costos operativos mínimos con un equipo de desarrollo ágil de 2 personas.

---

## 2. Opciones Consideradas

1. **Microservicios Distribuidos:**
   - *Pros:* Despliegue independiente por servicio.
   - *Contras:* Complejidad de red alta, latencia entre llamadas RPC/HTTP en horas pico, necesidad de transacciones distribuidas (Sagas) para validar disponibilidad de salones y sobrecosto de infraestructura.
2. **Monolito Tradicional Espagueti:**
   - *Pros:* Rápido de arrancar.
   - *Contras:* Alto acoplamiento, difícil de mantener y probar, riesgo de corrupción del modelo de datos de horarios.
3. **Monolito Modular (Seleccionada):**
   - *Pros:* Separación estricta de dominios (`schedules`, `attendance`, `session`, etc.), llamadas en memoria con latencia sub-milisegundo, transacciones ACID directas en PostgreSQL y despliegue simple en un solo contenedor.

---

## 3. Decisión Adoptada
Adoptar el patrón de **Monolito Modular**. Cada módulo se encapsula con su propia capa de dominio, aplicación e infraestructura, comunicándose exclusivamente a través de interfaces públicas (*Facades*).

---

## 4. Consecuencias
- **Positivas:**
  - Latencias mínimas para procesar ráfagas de escaneos matutinos.
  - Cero complejidad de red para validación de horarios y salones.
  - Facilidad de pruebas unitarias e integración en el pipeline de CI/CD.
- **Desafíos:**
  - Requiere disciplina estricta y linters automáticos de arquitectura para evitar importaciones directas entre módulos.

---

**Relacionado:** [`../../modular-monolith.md`](../../modular-monolith.md) · [`../../boundary-enforcement.md`](../../boundary-enforcement.md)
