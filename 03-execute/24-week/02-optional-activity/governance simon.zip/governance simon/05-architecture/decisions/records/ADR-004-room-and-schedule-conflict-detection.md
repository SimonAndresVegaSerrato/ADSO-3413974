# ADR-004: Motor de Detección de Conflictos de Horarios y Salones con Índices de Rango en PostgreSQL

**Estado:** Aprobado  
**Fecha:** 2026-09-19  
**Autores:** Juan Diego Hernández, Simón Andrés Vega Serrato  
**Decisores:** Equipo de Desarrollo  

---

## 1. Contexto y Planteamiento del Problema
La programación de horarios para salones (ambientes) y fichas de formación debe evitar a toda costa la doble asignación de salones, la superposición de clases para una misma ficha y la programación simultánea de un instructor. Se requiere un mecanismo de validación de colisiones de tiempo que sea instantáneo y resistente a condiciones de carrera concurrentes.

---

## 2. Opciones Consideradas

1. **Validación Exclusiva en Memoria / Aplicación:**
   - *Pros:* Código desacoplado de la base de datos.
   - *Contras:* Vulnerable a condiciones de carrera (*race conditions*) si dos coordinadores guardan asignaciones casi simultáneas.
2. **Consultas SQL con Bloqueos de Tabla (`SELECT FOR UPDATE`):**
   - *Pros:* Garantiza consistencia.
   - *Contras:* Degrada el rendimiento y puede generar bloqueos (*deadlocks*).
3. **Restricciones de Exclusión con Tipos de Rango e Índices GiST en PostgreSQL (Seleccionada):**
   - *Pros:* PostgreSQL soporta de forma nativa tipos de rango temporal (`tsrange` / `tstzrange`) y restricciones `EXCLUDE USING gist`. La propia base de datos impide a nivel de motor cualquier traslape temporal sobre el mismo salón o ficha con rendimiento óptimo.

---

## 3. Decisión Adoptada
Modelar las asignaciones de horarios en la tabla `schedules.schedule_assignments` utilizando tipos de rango temporal e índices GiST con restricciones de exclusión. La capa de aplicación (`schedules`) valida previamente la regla de negocio para brindar mensajes amigables al usuario, mientras que PostgreSQL actúa como guardián transaccional absoluto contra colisiones concurrentes.

---

## 4. Consecuencias
- **Positivas:**
  - 100% de garantía contra traslapes de salones y fichas, incluso bajo alta concurrencia de edición.
  - Consultas de disponibilidad de salones extremadamente rápidas mediante indexación GiST.
- **Desafíos:**
  - Requiere habilitar la extensión `btree_gist` en PostgreSQL durante las migraciones iniciales.

---

**Relacionado:** [`../../../06-data/models.md`](../../../06-data/models.md) · [`../../../02-domain/entities-and-rules.md`](../../../02-domain/entities-and-rules.md)
