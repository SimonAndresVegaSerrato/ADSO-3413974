# ADR-002: Validación de Códigos QR Dinámicos Firmados con JWT y TTL en Redis

**Estado:** Aprobado  
**Fecha:** 2026-09-19  
**Autores:** Juan Diego Hernández, Simón Andrés Vega Serrato  
**Decisores:** Equipo de Desarrollo  

---

## 1. Contexto y Planteamiento del Problema
Los sistemas tradicionales de asistencia con código QR estático impreso en papel o proyectado de forma fija sufren de fraude: los estudiantes fotografían el QR y lo comparten por aplicaciones de mensajería con compañeros ausentes. Se requiere un mecanismo de asistencia presencial infalsificable.

---

## 2. Opciones Consideradas

1. **Códigos QR Estáticos por Aula/Ficha:**
   - *Pros:* Muy fácil de implementar.
   - *Contras:* Fraude masivo inmediato mediante fotos compartidas.
2. **Tokens Efímeros en Base de Datos Relacional:**
   - *Pros:* Tokens temporales.
   - *Contras:* Cientos de escrituras y eliminaciones por minuto en PostgreSQL generan sobrecarga de I/O innecesaria.
3. **Tokens Criptográficos Dinámicos (JWT) con Rotación y TTL en Redis (Seleccionada):**
   - *Pros:* El servidor proyecta un QR que rota cada 30-300s firmado digitalmente. Redis gestiona la vigencia con TTL automático, permitiendo validaciones ultrarrápidas (< 5ms) sin tocar el disco.

---

## 3. Decisión Adoptada
Implementar el motor de asistencia utilizando **tokens JWT efímeros firmados por el backend (HMAC-SHA256)** que rotan continuamente en la pantalla del aula. La clave activa se conserva en Redis con TTL estricto. Cuando un aprendiz escanea, el backend valida la firma criptográfica y la vigencia activa en Redis.

---

## 4. Consecuencias
- **Positivas:**
  - Imposibilidad práctica de reenviar fotos de QR a distancia (el token expira antes de ser usado).
  - Alivio total de carga en PostgreSQL al usar Redis para datos transitorios de sesión.
- **Desafíos:**
  - Requiere que el proyector del aula mantenga conexión WebSocket continua para refrescar la imagen del QR.

---

**Relacionado:** [`../../../00-governance/security-policy.md`](../../../00-governance/security-policy.md) · [`ADR-003-network-and-geolocation-anti-fraud.md`](./ADR-003-network-and-geolocation-anti-fraud.md)
