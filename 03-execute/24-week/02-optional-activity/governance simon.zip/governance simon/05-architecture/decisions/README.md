# 05 — Architecture Decision Records (ADR)

Registro histórico e inmutable de las decisiones arquitectónicas clave adoptadas en el diseño del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📚 Índice de Decisiones Registradas

| ADR | Título | Estado | Fecha | Decisión Principal |
|---|---|---|---|---|
| [`ADR-001`](./records/ADR-001-modular-monolith-as-default.md) | Monolito Modular como Estilo Arquitectónico Base | **Aprobado** | 2026-09-19 | Adoptar un monolito modular en un solo proceso con aislamiento por fachadas en lugar de microservicios. |
| [`ADR-002`](./records/ADR-002-dynamic-jwt-signed-qr-validation.md) | Validación de Códigos QR Dinámicos Firmados con JWT y TTL en Redis | **Aprobado** | 2026-09-19 | Rotación de QR cada 30-300s firmado con JWT y validación en caché Redis para evitar fotos y fraudes. |
| [`ADR-003`](./records/ADR-003-network-and-geolocation-anti-fraud.md) | Validación Antifraude por Subred Institucional y Geocerca GPS | **Aprobado** | 2026-09-19 | Exigir pertenencia a la red IP de la sede y proximidad geográfica GPS para admitir el escaneo de asistencia. |
| [`ADR-004`](./records/ADR-004-room-and-schedule-conflict-detection.md) | Motor de Detección de Conflictos de Horarios y Salones con Índices de Rango | **Aprobado** | 2026-09-19 | Usar tipos de rango temporal e índices GiST en PostgreSQL para prevenir traslapes de aulas y fichas en tiempo real. |

---

## 📝 Plantilla
- Para registrar una nueva decisión arquitectónica, utilizar la plantilla [`_template-adr.md`](./_template-adr.md).
