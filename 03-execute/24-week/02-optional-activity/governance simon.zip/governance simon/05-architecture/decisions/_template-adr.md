# ADR-[Número]: [Título de la Decisión Arquitectónica]

**Estado:** `[Propuesto | Aprobado | Reemplazado | Rechazado]`  
**Fecha:** `YYYY-MM-DD`  
**Autores:** Juan Diego Hernández, Simón Andrés Vega Serrato  
**Decisores:** Todo el equipo  

---

## 1. Contexto y Planteamiento del Problema
[Describir la situación, necesidad técnica o requerimiento de negocio que motiva la decisión.]

---

## 2. Opciones Consideradas
1. **Opción A:** [Descripción, pros y contras]
2. **Opción B:** [Descripción, pros y contras]
3. **Opción C:** [Descripción, pros y contras]

---

## 3. Decisión Adoptada
[Explicar con claridad la opción seleccionada y los motivos técnicos fundamentales que la justifican.]

---

## 4. Consecuencias e Impacto
- **Positivas:** [Beneficios técnicos, operativos y de rendimiento obtenidos.]
- **Negativas / Desafíos:** [Compromisos (*trade-offs*), restricciones o riesgos que deben mitigarse.]

---
