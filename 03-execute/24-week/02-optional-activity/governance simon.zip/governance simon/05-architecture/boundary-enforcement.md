# 05 — Boundary Enforcement

Mecanismos de control automático y verificación de límites arquitectónicos para evitar que los módulos se acoplen de forma indebida en el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🛑 Reglas de Dependencia Prohibidas

Para evitar que el código degenere en un monolito no modular, el linter de arquitectura y las pruebas de CI validan que:

1. **Sin Importaciones Cruzadas Directas:**
   - Un archivo en `src/attendance/` **NO** puede importar clases internas de `src/schedules/infrastructure/` o `src/session/domain/`.
   - **Forma Correcta:** Inyectar la interfaz `SessionFacade` o `ScheduleFacade`.
2. **Sin Consultas SQL Cruzadas:**
   - Ninguna consulta SQL o migración puede realizar un `JOIN` directo entre esquemas de diferentes módulos en tiempo de ejecución de aplicación.
3. **Validación Automatizada en CI (ArchUnit / ImportLinter):**
   - En cada Pull Request ejecutado por Juan Diego Hernández o Simón Andrés Vega Serrato, el pipeline ejecuta un verificador de dependencias (`import-linter` o `pytest-archon`) para validar las reglas de aislamiento.

---

## 🧪 Ejemplo de Prueba Automatizada de Límites

```python
# tests/architecture/test_boundaries.py
def test_attendance_module_does_not_import_schedules_internals():
    """Valida que Attendance solo se comunique con Schedules via ScheduleFacade."""
    import importlib
    # Verifica que no existan llamadas a modelos o repositorios internos de schedules
    assert not direct_internal_imports_exist(
        source_package="src.attendance",
        forbidden_packages=["src.schedules.infrastructure", "src.schedules.domain"]
    )
```

---

**Relacionado:** [`modular-monolith.md`](./modular-monolith.md) · [`module-structure.md`](./module-structure.md)
