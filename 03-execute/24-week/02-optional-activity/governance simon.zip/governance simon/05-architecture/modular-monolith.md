# 05 — Modular Monolith

El **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** adopta el estilo arquitectónico de **Monolito Modular** (*Modular Monolith*).

Esta decisión estratégica permite combinar un aislamiento estricto de dominios (como si fueran microservicios) con la simplicidad operativa, transaccionalidad atómica y bajo costo de despliegue de un único artefacto ejecutable.

---

## 🏗️ Diagrama de Arquitectura del Monolito Modular

```mermaid
graph TD
    ClientApp["📱 Navegador Móvil (Aprendiz) / Portal Web (Instructor / Coordinador)"] --> Gateway["🌐 Reverse Proxy / Nginx Gateway"]
    Gateway --> Monolith["📦 Aplicación Monolito Modular"]

    subgraph Monolith
        REST["REST API Controllers & WebSocket Gateway"]
        
        subgraph Modules["🧩 Módulos Aislados en Memoria (In-Process)"]
            AuthModule["<b>auth</b>\nAuthFacade"]
            AcademicModule["<b>academic</b>\nAcademicFacade"]
            SchedulesModule["<b>schedules</b>\nScheduleFacade\n(Motor Anti-Traslapes)"]
            SessionModule["<b>session</b>\nSessionFacade\n(Ciclo QR Dinámico)"]
            AttendanceModule["<b>attendance</b>\nAttendanceFacade\n(Motor Antifraude)"]
            ReportsModule["<b>reports</b>\nReportsFacade"]
            AuditModule["<b>audit</b>\nAuditFacade"]
        end
    end

    SessionModule <--> RedisCache[("⚡ Redis Cache\n(Tokens QR Dinámicos / TTL 30s-300s)")]
    Modules --> RelationalDB[("🗄️ PostgreSQL\n(Schemas: auth, academic, schedules,\nsession, attendance, audit)")]
```

---

## 🌟 Justificación y Beneficios Clave

1. **Rendimiento Ultrarrápido en Picos de Clase:**
   - La comunicación entre el módulo de horarios (`schedules`), sesiones (`session`) y asistencias (`attendance`) ocurre en el mismo proceso de memoria (llamadas a métodos en memoria con latencias de microsegundos), ideal para procesar cientos de escaneos simultáneos a la hora de entrada.
2. **Consistencia Transaccional ACID:**
   - Permite verificar la disponibilidad de un salón e insertar una asignación de horario dentro de una única transacción SQL en PostgreSQL, imposibilitando condiciones de carrera que generen traslapes de aulas.
3. **Caché Especializado en Memoria (Redis):**
   - La rotación continua de tokens QR efímeros se respalda en Redis con TTL automático, liberando a PostgreSQL de escrituras transitorias y garantizando validaciones de token en < 5 ms.
4. **Bajo Costo de Mantenimiento para Equipo de 2:**
   - Facilita a Juan Diego Hernández y Simón Andrés Vega Serrato construir, probar y desplegar la solución sin la sobrecarga de mantener múltiples pipelines, orquestadores Kubernetes o redes distribuidas.

---

**Relacionado:** [`layered-architecture.md`](./layered-architecture.md) · [`module-structure.md`](./module-structure.md) · [`decisions/records/ADR-001-modular-monolith-as-default.md`](./decisions/records/ADR-001-modular-monolith-as-default.md)
