# 01 — Scope

Límites explícitos de lo que está **incluido (In-Scope)** y lo que queda **fuera de alcance (Out-of-Scope)** en el **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🎯 Dentro del Alcance (In-Scope)

### 1. Gestión y Control de Horarios
- **Programación de Franjas Horarias:** Creación de bloques horarios recurrentes por días de la semana y fechas específicas.
- **Asignación de Salones y Fichas:** Vinculación de ficha formativa, instructor responsable y salón específico.
- **Detección y Bloqueo de Conflictos:** Validación automática para evitar traslape de salón (un aula ocupada por dos fichas), traslape de ficha (una ficha con dos clases simultáneas) y traslape de instructor.
- **Control de Aforo y Capacidad:** Alertas y restricciones si la cantidad de aprendices de la ficha supera la capacidad máxima del salón asignado.

### 2. Control de Asistencia con Código QR Dinámico
- **Generación de QR Efímero (JWT):** Proyección en pantalla de un código QR firmado con rotación automática cada 30 a 300 segundos.
- **Validación Antifraude:** Verificación simultánea de token JWT activo en Redis, subred IP institucional y geocerca GPS.
- **Doble Marcación (Horas Reales):** Registro de ingreso (*check-in*) y salida (*check-out*) con cálculo automático de horas efectivas.
- **Cierre y Marcación Automática:** Marcación de aprendices ausentes como `INASISTENTE` al vencer la ventana de escaneo.
- **Ajustes y Justificaciones:** Registro manual de justificaciones médicas o casos excepcionales con bitácora inmutable.
- **Importación de Nóminas Sofia Plus:** Copiado y pegado masivo de documentos con validación automática y vinculación a fichas.

---

## 🚫 Fuera del Alcance (Out-of-Scope)

| Capacidad Fuera de Alcance | Motivo / Alternativa |
|---|---|
| **Conexión Directa a la Base de Datos de Sofia Plus** | Sofia Plus no ofrece API pública abierta para escritura. La carga de aprendices se realiza por importación rápida de listas estructuradas. |
| **Evaluación Pedagógica de Competencias** | El sistema se concentra en horarios y asistencia; las calificaciones y juicios evaluativos corresponden a los sistemas académicos oficiales. |
| **Biometría Facial con Cámaras Especializadas** | Se descarta por altos costos de hardware y mantenimiento en aulas estándar. |
| **Envío de Notificaciones por SMS de Pago** | Las alertas se transmiten mediante correo institucional y la aplicación web. |

---

**Relacionado:** [`overview.md`](./overview.md) · [`../04-requirements/user-stories.md`](../04-requirements/user-stories.md)
