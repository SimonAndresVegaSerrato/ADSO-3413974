# 01 — Context

Visión global, contexto institucional, alcance y terminología del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 🎯 Propósito del Sistema

El sistema resuelve dos grandes desafíos operativos en instituciones educativas y centros de formación (como el SENA):
1. **La gestión y control eficiente de horarios, salones (ambientes) y fichas**, eliminando conflictos de espacio, salones duplicados y cruces de horarios.
2. **El registro de asistencia ágil, seguro e infalsificable mediante códigos QR dinámicos**, garantizando la presencia física de los aprendices y calculando con exactitud las horas reales de formación.

---

## 📚 Documentos de esta sección

| Documento | Pregunta que responde |
|---|---|
| [`overview.md`](./overview.md) | ¿Cómo interactúan los actores (instructores, aprendices, coordinadores) con el sistema y cuál es el flujo de información? |
| [`scope.md`](./scope.md) | ¿Qué funcionalidades están estrictamente incluidas en el sistema y cuáles quedan fuera de alcance? |
| [`glossary.md`](./glossary.md) | ¿Qué significan los términos clave del dominio (Ficha, Salón/Ambiente, Franja Horaria, QR Dinámico, Sofia Plus)? |

---

**Siguiente sección:** [`02-domain/README.md`](../02-domain/README.md)
