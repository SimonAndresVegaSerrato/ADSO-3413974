# 01 — Overview

El **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas** es una solución integral diseñada para organizar la ocupación física de aulas y optimizar el registro de asistencia formativa.

---

## 🔄 Flujo General del Sistema

```mermaid
flowchart TD
    subgraph Coordinacion["🏛️ Coordinación Académica"]
        Plan["1. Planifica y Asigna Horarios\n(Salones, Fichas, Instructores)"]
        AuditView["6. Monitoreo en Vivo,\nAforos y Horas Reales"]
    end

    subgraph Instructor["👨‍🏫 Instructor de Formación"]
        CheckSchedule["2. Consulta Horario y Salón"]
        OpenSession["3. Abre Sesión de Clase\n(Dentro de Horario Válido)"]
        ProjectQR["4. Proyecta QR Dinámico\n(Rota cada 30-300s)"]
        ManualAdjust["7. Justificaciones y Cierre"]
    end

    subgraph Aprendiz["📱 Aprendiz / Estudiante"]
        Scan["5. Conecta a Red Institucional,\nEscanea QR y Autentica"]
    end

    subgraph Backend["⚙️ Monolito Modular"]
        Validation["Validación Integral:\n- Token JWT activo en Redis\n- Red WiFi + Geocerca GPS\n- Pertenencia a Ficha\n- Salón y Horario Programado"]
        DBRecord[("PostgreSQL\nAsistencias, Horarios,\nSalones y Auditoría")]
    end

    Plan --> CheckSchedule
    CheckSchedule --> OpenSession
    OpenSession --> ProjectQR
    ProjectQR -.-> Scan
    Scan --> Validation
    Validation --> DBRecord
    DBRecord --> ManualAdjust
    DBRecord --> AuditView
```

---

## 👥 Usuarios y Roles Principales

| Rol | Responsabilidades en Horarios | Responsabilidades en Asistencia QR |
|---|---|---|
| **Aprendiz** | Consultar en qué salón, día y franja horaria le corresponde su formación. | Conectarse a la red WiFi del centro, escanear el QR dinámico en pantalla y registrar entrada y salida. |
| **Instructor** | Consultar su cronograma de clases, ambiente asignado y nómina de la ficha. | Abrir la sesión de clase, proyectar el QR rotativo, atender excepciones manuales justificadas y cerrar la sesión. |
| **Coordinador Académico** | Crear franjas horarias, asignar salones y fichas resolviendo traslapes; supervisar aforos. | Auditar el porcentaje de asistencia en tiempo real, generar reportes consolidados y detectar alertas tempranas de deserción. |
| **Administrador TI** | Dar de alta sedes, tipos de salones, geocercas y rangos IP institucionales. | Configurar claves criptográficas JWT, políticas de retención y variables de infraestructura. |

---

## 💡 Propuesta de Valor

1. **Cero Conflictos de Salones y Horarios:** El motor valida en tiempo real la disponibilidad de espacios y grupos, impidiendo duplicidad de aulas o cruces de horarios.
2. **Asistencia Rápida e Infalsificable:** El pase de lista pasa de tomar 15 minutos en papel a menos de 10 segundos por aprendiz mediante QR dinámicos rotativos.
3. **Cálculo Exacto de Horas Reales:** Soporte para doble marcación (check-in y check-out) para auditar con total precisión el tiempo efectivo de formación.

---

**Relacionado:** [`scope.md`](./scope.md) · [`glossary.md`](./glossary.md) · [`../03-product/vision.md`](../03-product/vision.md)
