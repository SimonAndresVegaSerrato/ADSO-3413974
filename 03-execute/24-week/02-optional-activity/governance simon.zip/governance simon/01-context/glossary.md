# 01 — Glossary

Glosario de términos clave del dominio del **Sistema de Control de Asistencia y Gestión de Horarios de Salones y Fichas**.

---

## 📖 Conceptos de Horarios y Espacios Físicos

| Término | Definición |
|---|---|
| **Salón / Ambiente de Formación** | Espacio físico (aula de clase, taller práctico o laboratorio de cómputo) identificado con un código único, capacidad máxima de aforo y sede perteneciente. |
| **Ficha** | Código numérico único que identifica a una cohorte o grupo de aprendices matriculados en un programa de formación específico. |
| **Franja Horaria (Time Slot)** | Bloque de tiempo delimitado por hora de inicio, hora de fin y días de la semana (ej. Lunes a Viernes 07:00 a 13:00). |
| **Asignación de Horario (Schedule Assignment)** | Registro que vincula una Ficha, un Instructor, un Salón y una Franja Horaria durante un periodo determinado. |
| **Conflicto / Traslape de Salón** | Situación inválida en la que dos fichas distintas intentan ocupar el mismo salón en el mismo intervalo de tiempo. |
| **Conflicto / Traslape de Ficha** | Situación inválida en la que una misma ficha tiene programadas dos actividades o salones diferentes en el mismo horario. |
| **Aforo Máximo** | Límite máximo de personas permitidas en un salón por motivos pedagógicos y de seguridad. |

---

## 📱 Conceptos de Asistencia y QR Dinámico

| Término | Definición |
|---|---|
| **Código QR Dinámico** | Código QR proyectado por el instructor en la pantalla del aula que cambia automáticamente cada 30 a 300 segundos, conteniendo un token firmado. |
| **Token Criptográfico Efímero (JWT)** | Token firmado con clave secreta que expira rápidamente y cuya vigencia se almacena en caché Redis para evitar su reutilización o envío por mensajería. |
| **Doble Marcación** | Mecanismo que requiere un escaneo al entrar (*check-in*) y otro al salir (*check-out*) para computar con exactitud las horas reales de formación. |
| **Ventana de Registro** | Intervalo de tiempo configurado por el instructor (ej. primeros 15 minutos de clase) durante el cual el sistema admite escaneos de asistencia. |
| **Geocerca GPS** | Radio geográfico en metros alrededor de las coordenadas del centro de formación donde es válido el escaneo móvil. |
| **Sofia Plus** | Sistema oficial de gestión académica y matrícula del SENA desde donde se exportan los listados de aprendices. |

---

**Relacionado:** [`overview.md`](./overview.md) · [`../02-domain/entities-and-rules.md`](../02-domain/entities-and-rules.md)
